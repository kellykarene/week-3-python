#Simple calculator in python example with **Kelly**

#Enter first number
num1 = int(input("please enter number 1\n"))

#Enter second number
num2= int(input("please enter number 2\n"))

#then ask the user to choose an option
ans= input("choose option: \n a) Addition \n b) Subtraction \n c) Multiplication \n d) Division \n")

#if statement

#Addition
if ans=="a":
    print(num1+num2)

#Subtraction
if ans=="b":
    print (num1-num2)

#Multiplication
if ans=="c":
    print (num1*num2)

#Division
if ans=="d":
    print (num1/ num2)
