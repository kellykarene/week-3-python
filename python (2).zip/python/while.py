#while loop

#inex set to 0
index=0


#while loop structure

while index<10:
    index=index+1
    print(index)
