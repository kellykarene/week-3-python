Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:20:19) [MSC v.1925 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: C:/Users/Karren/Desktop/python/HelloWorld.py ============
Hello World
>>> 
================ RESTART: C:/Users/Karren/Desktop/python/Calc.py ===============
please enter number 1
2
please enter number 2
5
choose option: 
 a) Addition 
 b) Subtraction 
 c) Multiplication 
 d) Division 
b
-3
>>> 
============== RESTART: C:/Users/Karren/Desktop/python/Student.py ==============
please enter your name: 
Khanyisile
please enter your surname: 
Dube
please enter your age 
23
please enter mark for subject 1: 
44
please enter mark for subject 2: 
66
please enter mark for subject 3: 
58
Student Name is:
 Khanyisile
Student Surname is:
 Dube
The total avarage mark is:
 56
>>> 
============== RESTART: C:/Users/Karren/Desktop/python/Student.py ==============
please enter your name: 
john
please enter your surname: 
smith
please enter your age 
23
please enter mark for subject 1: 
55
please enter mark for subject 2: 
69
please enter mark for subject 3: 
85
Student Name is:
 john
Student Surname is:
 smith
The total avarage mark is:
 69
Welcome, you have passed
>>> 
>>> 